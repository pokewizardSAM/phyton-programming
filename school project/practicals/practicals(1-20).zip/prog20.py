import mysql.connector

def delete_employee_record():
    try:
        conn = mysql.connector.connect(
            host='localhost',
            user='your_username',
            password='your_password',
            database='your_database'
        )

        if conn.is_connected():
            print("Connected to MySQL database")

            emp_no = input("Enter employee number to delete: ")

            cursor = conn.cursor()

            delete_query = "DELETE FROM employees WHERE emp_no = %s"
            data = (emp_no,)

            cursor.execute(delete_query, data)

            conn.commit()

            if cursor.rowcount == 0:
                print(f"No employee record found with employee number {emp_no}")
            else:
                print(f"Employee record with employee number {emp_no} deleted successfully")

            cursor.close()
            conn.close()

    except mysql.connector.Error as error:
        print("Error:", error)

delete_employee_record()
