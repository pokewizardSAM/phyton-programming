her_in_same_period,"dwdwdwdwdwdwdwdwdwdwd")
                    # print(period_no)